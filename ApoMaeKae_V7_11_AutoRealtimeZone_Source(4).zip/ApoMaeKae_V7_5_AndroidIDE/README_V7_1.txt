อาโปแมะเก๊ V7.1 สำหรับ AndroidIDE

แก้จาก V7:
- เพิ่ม ./gradlew ที่ AndroidIDE เรียกหา
- ไม่ใช้ AAPT2 override ของ Termux
- ไม่ล็อก SDK path ของ Termux
- คง assets/โค้ดเดิม รวม zones.json และ Buffer 500m

วิธี:
1. ลบ/ปิดโปรเจกต์ V7 เดิมใน AndroidIDE
2. แตก ZIP V7.1
3. Open existing project > ApoMaeKae_V7_1_AndroidIDE
4. กด Build/Run
5. ถ้าขึ้น error ใหม่ ให้ส่งภาพ Build Info มา
