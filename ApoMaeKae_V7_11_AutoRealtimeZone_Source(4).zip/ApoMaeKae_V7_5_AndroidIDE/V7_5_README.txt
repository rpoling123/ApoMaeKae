ApoMaeKae V7.5 AndroidIDE compatibility build
Target build environment: Gradle 6.1.1
Android Gradle Plugin: 4.0.2 where declared in build.gradle
Wrapper: Gradle 6.1.1
This version is intended to address the AndroidIDE error reporting current Gradle 6.1.1.
