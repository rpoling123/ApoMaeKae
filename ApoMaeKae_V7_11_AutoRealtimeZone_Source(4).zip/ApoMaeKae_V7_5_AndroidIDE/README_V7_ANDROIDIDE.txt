อาโปแมะเก๊ V7 — AndroidIDE Edition

V7 ตัด AAPT2 override ของ Termux ออก ให้ AndroidIDE ใช้ toolchain ของ AndroidIDE เอง

มี:
- 39 Polygon / 4 ชุดมังกร
- Buffer 500 เมตร
- GPS ตรวจเข้า/ออก Polygon
- แจ้งเตือนออกนอกโซน / กลับเข้าโซน
- ติ๊กเปิด/ปิดแต่ละชุด
- Foreground location service
- zones.json ฝังในแอป ตรวจ Polygon แบบออฟไลน์
- ปุ่มเปิด Dragon Maps

Project:
compileSdk 35 / targetSdk 35 / minSdk 24
AGP 8.7.3 / Gradle 8.9
ไม่มี android.aapt2FromMavenOverride
ไม่มี local.properties ที่ชี้ Termux

วิธี:
1) แตก ZIP
2) AndroidIDE > Open existing project
3) เลือกโฟลเดอร์ ApoMaeKae_V7_AndroidIDE ที่เห็น settings.gradle และ app
4) รอ Sync; ถ้าขอ SDK ให้ติดตั้ง Android 35
5) กด Quick Run / Build APK
6) APK ปกติ: app/build/outputs/apk/debug/app-debug.apk

สำคัญ: นี่คือ source project สำหรับ AndroidIDE ไม่ใช่ APK ที่ compile แล้ว
