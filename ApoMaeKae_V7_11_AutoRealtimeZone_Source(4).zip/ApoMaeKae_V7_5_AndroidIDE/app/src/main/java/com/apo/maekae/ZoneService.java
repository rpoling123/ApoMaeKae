package com.apo.maekae;

import android.app.*;
import android.content.*;
import android.location.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.*;
import android.widget.*;
import android.provider.Settings;
import org.json.*;
import java.io.*;

public class ZoneService extends Service implements LocationListener {
    private static final String CHANNEL="guard";
    private static final int FG_ID=77;
    JSONArray groups;
    NotificationManager nm;
    LocationManager lm;
    Location lastLocation;
    boolean lastSafe=true;
    int lastLevel=-1;
    double bufferMeters=500.0;
    WindowManager wm; View overlay; Handler overlayHandler=new Handler(Looper.getMainLooper());
    BroadcastReceiver shopReceiver;

    @Override public void onCreate(){
        super.onCreate();
        nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Zone Lock",NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
        try(InputStream in=getAssets().open("zones.json")){
            byte[] b=new byte[in.available()]; in.read(b);
            JSONObject root=new JSONObject(new String(b,"UTF-8"));
            groups=root.getJSONArray("groups");
            bufferMeters=root.optDouble("bufferMeters",500.0);
        }catch(Exception e){ groups=new JSONArray(); }
        shopReceiver=new BroadcastReceiver(){ @Override public void onReceive(Context c,Intent i){ checkShop(i); } };
        IntentFilter sf=new IntentFilter("com.apo.maekae.SHOP_CANDIDATE");
        if(Build.VERSION.SDK_INT>=33) registerReceiver(shopReceiver,sf,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(shopReceiver,sf);
    }

    @Override public int onStartCommand(Intent i,int flags,int id){
        startForeground(FG_ID,buildNotification("Zone Lock ทำงานอยู่","กำลังตรวจ GPS • กันหลุดโซน "+(int)bufferMeters+" เมตร",false));
        try{
            lm=(LocationManager)getSystemService(LOCATION_SERVICE);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,3000,5,this);
            if(lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000,10,this);
        }catch(SecurityException ignored){}
        return START_STICKY;
    }

    @Override public void onLocationChanged(Location l){
        lastLocation=l;
        boolean inside=false;
        double nearest=Double.MAX_VALUE;
        String hit="";
        android.content.SharedPreferences p=getSharedPreferences("z",0);
        try{
            for(int g=0;g<groups.length();g++){
                if(!p.getBoolean("g"+g,true)) continue;
                JSONObject gr=groups.getJSONObject(g);
                JSONArray ps=gr.getJSONArray("polygons");
                for(int k=0;k<ps.length();k++){
                    JSONArray a=ps.getJSONObject(k).getJSONArray("points");
                    ZoneResult r=checkPolygon(l.getLatitude(),l.getLongitude(),a);
                    nearest=Math.min(nearest,r.distance);
                    if(r.inside){ inside=true; hit=gr.optString("name","โซนที่เลือก"); break; }
                }
                if(inside) break;
            }
        }catch(Exception ignored){}

        // Level: 0 safe (>500m inside), 1 warning (<=500m from edge), 2 outside but within buffer, 3 outside > buffer
        int level;
        if(inside) level = nearest<=bufferMeters ? 1 : 0;
        else level = nearest<=bufferMeters ? 2 : 3;

        String title, text;
        if(level==0){ title="🟢 อยู่ในโซน"; text=hit+" • ห่างขอบประมาณ "+meters(nearest); }
        else if(level==1){ title="🟡 ใกล้ขอบโซน"; text="เหลือประมาณ "+meters(nearest)+" ถึงขอบ • ระวังหลุดโซน"; }
        else if(level==2){ title="🟠 หลุดขอบแล้ว"; text="ออกนอก Polygon ประมาณ "+meters(nearest)+" • ยังอยู่ใน Buffer "+(int)bufferMeters+" ม."; }
        else { title="🔴 ออกนอก Zone Lock"; text="เกินกรอบประมาณ "+meters(nearest)+" • ให้กลับเข้าโซน"; }

        nm.notify(FG_ID,buildNotification(title,text,level>=1));
        if(level!=lastLevel){
            if(level==1) alert("ใกล้หลุดโซน","เหลือประมาณ "+meters(nearest)+" ถึงขอบโซน");
            else if(level==2) alert("ออกนอกขอบโซนแล้ว","ห่างขอบประมาณ "+meters(nearest));
            else if(level==3) alert("ออกนอก Zone Lock","เกิน Buffer "+(int)bufferMeters+" เมตรแล้ว");
            else if(lastLevel>0) alert("กลับเข้าโซนปลอดภัยแล้ว",hit);
            vibrate(level);
        }
        showScreenAlert(level,title,text);
        lastLevel=level;
        lastSafe=level<3;
        p.edit().putInt("level",level).putString("zoneStatus",title+"\n"+text).apply();
        sendBroadcast(new Intent("com.apo.maekae.ZONE_STATUS").setPackage(getPackageName()).putExtra("status",title+"\n"+text));
    }


    private void checkShop(Intent i){
        String shop=i.getStringExtra("shop"); if(shop==null||shop.trim().length()==0) shop="ร้านจาก LINE MAN";
        String result;
        if(!i.getBooleanExtra("hasCoords",false)){
            result="ร้านล่าสุด: "+shop+"\n⚪ พบชื่อร้าน แต่การแจ้งเตือนไม่ได้ส่งพิกัด จึงยังระบุใน/นอกโซนไม่ได้";
        } else {
            double lat=i.getDoubleExtra("lat",0), lon=i.getDoubleExtra("lon",0); boolean inside=false; String hit="";
            try{ for(int g=0;g<groups.length()&&!inside;g++){JSONObject gr=groups.getJSONObject(g);JSONArray ps=gr.getJSONArray("polygons");for(int k=0;k<ps.length();k++){if(checkPolygon(lat,lon,ps.getJSONObject(k).getJSONArray("points")).inside){inside=true;hit=gr.optString("name","โซน");break;}}} }catch(Exception ignored){}
            String dist=""; boolean overRadius=false;
            if(lastLocation!=null){
                float[] rr=new float[1]; Location.distanceBetween(lastLocation.getLatitude(),lastLocation.getLongitude(),lat,lon,rr);
                float radiusKm=getSharedPreferences("v79",0).getFloat("radius_km",2.0f);
                overRadius=rr[0]>(radiusKm*1000f); dist=" • ห่างคุณ "+meters(rr[0])+" / ตั้งไว้ "+String.format(java.util.Locale.US,"%.1f",radiusKm)+" กม.";
            }
            result="ร้านล่าสุด: "+shop+"\n"+(inside?"🟢 ร้านอยู่ในโซน • "+hit:"🔴 ร้านอยู่นอกโซน")+dist+(overRadius?"\n⚠️ เกินระยะเตือนที่ตั้งไว้":"");
        }
        getSharedPreferences("z",0).edit().putString("shopStatus",result).apply();
        getSharedPreferences("v79",0).edit().putString("shopStatus",result).apply();
        sendBroadcast(new Intent("com.apo.maekae.SHOP_STATUS").setPackage(getPackageName()).putExtra("status",result));
    }

    private void showScreenAlert(int level,String title,String text){
        if(Build.VERSION.SDK_INT<23 || !Settings.canDrawOverlays(this)) return;
        hideOverlay();
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(34,22,34,22);
        int bg=level>=3?Color.rgb(198,40,40):(level==2?Color.rgb(239,108,0):(level==1?Color.rgb(249,168,37):Color.rgb(46,125,50)));
        box.setBackgroundColor(bg);
        TextView t=new TextView(this); t.setText(title); t.setTextColor(Color.WHITE); t.setTextSize(22); t.setTypeface(null,1);
        TextView x=new TextView(this); x.setText(text); x.setTextColor(Color.WHITE); x.setTextSize(17); x.setPadding(0,8,0,0);
        box.addView(t); box.addView(x);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP; lp.y=70;
        overlay=box; try{wm.addView(overlay,lp);}catch(Exception e){overlay=null;return;}
        // V7.11: overlay is live and is replaced on every GPS update; no timeout.
    }
    private void hideOverlay(){ if(overlay!=null){ try{wm.removeView(overlay);}catch(Exception ignored){} overlay=null; } }

    private Notification buildNotification(String t,String x,boolean alert){
        Notification.Builder b=new Notification.Builder(this,Build.VERSION.SDK_INT>=26?CHANNEL:"")
                .setContentTitle(t).setContentText(x).setStyle(new Notification.BigTextStyle().bigText(x))
                .setSmallIcon(alert?android.R.drawable.ic_dialog_alert:android.R.drawable.ic_menu_mylocation)
                .setOngoing(true).setOnlyAlertOnce(true);
        return b.build();
    }
    private void alert(String t,String x){
        Notification n=new Notification.Builder(this,Build.VERSION.SDK_INT>=26?CHANNEL:"")
                .setContentTitle(t).setContentText(x).setStyle(new Notification.BigTextStyle().bigText(x))
                .setSmallIcon(android.R.drawable.ic_dialog_alert).setAutoCancel(true).build();
        nm.notify((int)(System.currentTimeMillis()%100000)+100,n);
    }
    private void vibrate(int level){
        if(level<=0)return;
        Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);
        if(v==null)return;
        long ms=level==1?250:(level==2?500:900);
        if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(ms,VibrationEffect.DEFAULT_AMPLITUDE)); else v.vibrate(ms);
    }
    private String meters(double d){ if(d==Double.MAX_VALUE)return "ไม่ทราบ"; return d>=1000?String.format(java.util.Locale.US,"%.1f กม.",d/1000.0):((int)Math.round(d))+" ม."; }

    static class ZoneResult { boolean inside; double distance; ZoneResult(boolean i,double d){inside=i;distance=d;} }
    private ZoneResult checkPolygon(double lat,double lon,JSONArray a)throws Exception{
        int n=a.length(); boolean c=false; double min=Double.MAX_VALUE;
        for(int i=0,j=n-1;i<n;j=i++){
            JSONArray pi=a.getJSONArray(i), pj=a.getJSONArray(j);
            double yi=pi.getDouble(0),xi=pi.getDouble(1),yj=pj.getDouble(0),xj=pj.getDouble(1);
            if(((yi>lat)!=(yj>lat))&&(lon<(xj-xi)*(lat-yi)/(yj-yi+1e-15)+xi)) c=!c;
            min=Math.min(min,segMeters(lat,lon,yi,xi,yj,xj));
        }
        return new ZoneResult(c,min);
    }
    private double segMeters(double lat,double lon,double a,double b,double c,double d){
        double ky=111320, kx=111320*Math.cos(Math.toRadians(lat));
        double px=lon*kx,py=lat*ky,x1=b*kx,y1=a*ky,x2=d*kx,y2=c*ky;
        double dx=x2-x1,dy=y2-y1,t=((px-x1)*dx+(py-y1)*dy)/(dx*dx+dy*dy+1e-9);
        t=Math.max(0,Math.min(1,t)); return Math.hypot(px-(x1+t*dx),py-(y1+t*dy));
    }
    @Override public void onDestroy(){ hideOverlay(); if(lm!=null)try{lm.removeUpdates(this);}catch(Exception ignored){} if(shopReceiver!=null)try{unregisterReceiver(shopReceiver);}catch(Exception ignored){} super.onDestroy(); }
    public void onProviderEnabled(String p){} public void onProviderDisabled(String p){} public void onStatusChanged(String p,int s,Bundle b){}
    public IBinder onBind(Intent i){return null;}
}
