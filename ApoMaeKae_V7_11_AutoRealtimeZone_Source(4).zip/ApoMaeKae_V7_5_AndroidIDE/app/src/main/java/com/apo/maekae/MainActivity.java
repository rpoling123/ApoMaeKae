package com.apo.maekae;
import android.app.*; import android.os.*; import android.content.*; import android.content.pm.PackageManager;
import android.Manifest; import android.net.Uri; import android.widget.*;
public class MainActivity extends Activity {
 CheckBox[] boxes=new CheckBox[4];
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  boxes[0]=findViewById(R.id.g1);boxes[1]=findViewById(R.id.g2);boxes[2]=findViewById(R.id.g3);boxes[3]=findViewById(R.id.g4);
  android.content.SharedPreferences p=getSharedPreferences("z",0);
  for(int i=0;i<4;i++){boxes[i].setChecked(p.getBoolean("g"+i,true)); final int j=i; boxes[i].setOnCheckedChangeListener((x,c)->p.edit().putBoolean("g"+j,c).apply());}
  findViewById(R.id.start).setOnClickListener(v->startGuard());
  findViewById(R.id.lineman).setOnClickListener(v->openLineMan());
  findViewById(R.id.web).setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://dragonmaps-lp7unspw.manus.space/"))));
  if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10);
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},11);
  if(Build.VERSION.SDK_INT>=23 && !android.provider.Settings.canDrawOverlays(this)){
    Toast.makeText(this,"เปิดสิทธิ์ แสดงทับแอปอื่น เพื่อให้ Zone Lock ขึ้นเตือนบนจอ",Toast.LENGTH_LONG).show();
    startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
  }
 }
 void openLineMan(){
  Intent launch=getPackageManager().getLaunchIntentForPackage("com.linecorp.lineman.driver");
  if(launch!=null){ launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); }
  else {
   Toast.makeText(this,"ยังไม่พบ LINE MAN RIDER ในเครื่อง",Toast.LENGTH_LONG).show();
   try{ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=com.linecorp.lineman.driver"))); }
   catch(Exception e){ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id=com.linecorp.lineman.driver"))); }
  }
 }
 void startGuard(){Intent i=new Intent(this,ZoneService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
  ((TextView)findViewById(R.id.status)).setText("กำลังตรวจ GPS • Buffer 500 เมตร • ทำงานเบื้องหลัง");}
}