package com.apo.maekae;
import android.app.Service; import android.content.*; import android.graphics.*; import android.os.IBinder;
import android.provider.Settings; import android.view.*; import android.widget.TextView;
public class JobAlertOverlayService extends Service {
 WindowManager w; TextView v;
 public int onStartCommand(Intent i,int f,int id) {
  if(!Settings.canDrawOverlays(this)) return START_NOT_STICKY;
  w=(WindowManager)getSystemService(WINDOW_SERVICE); v=new TextView(this);
  String m=i==null?null:i.getStringExtra("message");
  v.setText("LINE MAN RIDER\n"+(m==null||m.isEmpty()?"มีการแจ้งเตือนใหม่":m)+"\nแตะเพื่อเปิด LINE MAN Rider");
  v.setTextColor(Color.WHITE);v.setTextSize(18);v.setPadding(30,24,30,24);v.setBackgroundColor(0xEE15803D);
  v.setOnClickListener(x->{Intent q=getPackageManager().getLaunchIntentForPackage("com.linecorp.lineman.driver");if(q!=null){q.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(q);}stopSelf();});
  int t=android.os.Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
  WindowManager.LayoutParams p=new WindowManager.LayoutParams(-1,-2,t,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP;w.addView(v,p);v.postDelayed(this::stopSelf,10000);return START_NOT_STICKY;
 }
 public void onDestroy(){if(w!=null&&v!=null)try{w.removeView(v);}catch(Exception e){}super.onDestroy();}
 public IBinder onBind(Intent i){return null;}
}