package com.apo.maekae;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;

public class AutoCompanionActivity extends Activity {
    private static final String LINEMAN = "com.linecorp.lineman.driver";
    private SharedPreferences prefs;
    private TextView status, shopStatus, radiusText;
    private SeekBar radius;

    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            if("com.apo.maekae.ZONE_STATUS".equals(i.getAction())) status.setText(i.getStringExtra("status"));
            if("com.apo.maekae.SHOP_STATUS".equals(i.getAction())) shopStatus.setText(i.getStringExtra("status"));
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("v79",MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,24,28,24); root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title=new TextView(this); title.setText("อาโปแมะเก๊ V7.11 • AUTO REALTIME ZONE"); title.setTextSize(22); title.setTextColor(Color.rgb(0,128,80)); root.addView(title);
        TextView sub=new TextView(this); sub.setText("อัปเดตสถานะอัตโนมัติ • เข้า/ใกล้ขอบ/ออกโซน • ตรวจร้าน + ระยะ"); sub.setTextSize(16); sub.setPadding(0,8,0,12); root.addView(sub);
        radiusText=new TextView(this); radiusText.setTextSize(18); root.addView(radiusText);
        radius=new SeekBar(this); radius.setMax(3); int saved=prefs.getInt("radius_step",3); radius.setProgress(saved); root.addView(radius,new LinearLayout.LayoutParams(-1,-2)); updateRadius(saved);
        radius.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean f){updateRadius(p);prefs.edit().putInt("radius_step",p).apply();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });
        addButton(root,"เริ่มงาน + เปิด LINE MAN RIDER",new View.OnClickListener(){public void onClick(android.view.View v){startWork();}});
        addButton(root,"หยุด COMPANION",new View.OnClickListener(){public void onClick(android.view.View v){stopWork();}});
        addButton(root,"เปิดสิทธิ์ NOTIFICATION ACCESS",new View.OnClickListener(){public void onClick(android.view.View v){startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));}});
        addButton(root,"เปิดสิทธิ์แสดงทับแอปอื่น",new View.OnClickListener(){public void onClick(android.view.View v){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));}});
        status=new TextView(this); status.setTextSize(17); status.setPadding(0,22,0,6); status.setText(getSharedPreferences("z",0).getString("zoneStatus","สถานะ GPS: พร้อมเริ่มงาน")); root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        shopStatus=new TextView(this); shopStatus.setTextSize(17); shopStatus.setPadding(0,10,0,0); shopStatus.setText(prefs.getString("shopStatus","ร้านล่าสุด: ยังไม่มีข้อมูล")); root.addView(shopStatus,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
        requestNeededPermissions();
    }
    private void addButton(LinearLayout root,String text,android.view.View.OnClickListener l){Button b=new Button(this);b.setText(text);b.setOnClickListener(l);root.addView(b,new LinearLayout.LayoutParams(-1,-2));}
    private void updateRadius(int step){double km=0.5+step*0.5;radiusText.setText("รัศมีเตือนงาน: "+km+" กม. (สูงสุด 2 กม.)");prefs.edit().putFloat("radius_km",(float)km).apply();}
    private void requestNeededPermissions(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},11);
    }
    private void startWork(){
        Intent svc=new Intent(this,ZoneService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(svc); else startService(svc);
        status.setText("กำลังจับ GPS เรียลไทม์…");
        Intent launch=getPackageManager().getLaunchIntentForPackage(LINEMAN); if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(launch);}else Toast.makeText(this,"ไม่พบ LINE MAN Rider ในเครื่อง",Toast.LENGTH_LONG).show();
    }
    private void stopWork(){stopService(new Intent(this,ZoneService.class));status.setText("หยุด Companion แล้ว");}
    @Override protected void onStart(){super.onStart();IntentFilter f=new IntentFilter();f.addAction("com.apo.maekae.ZONE_STATUS");f.addAction("com.apo.maekae.SHOP_STATUS");if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);}
    @Override protected void onStop(){try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onStop();}
}
