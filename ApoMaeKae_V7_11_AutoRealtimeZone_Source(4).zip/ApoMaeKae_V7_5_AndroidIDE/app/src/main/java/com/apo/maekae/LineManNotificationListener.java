package com.apo.maekae;
import android.app.Notification;
import android.content.Intent;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.regex.*;
public class LineManNotificationListener extends NotificationListenerService {
 public void onNotificationPosted(StatusBarNotification s) {
  if(s==null || !"com.linecorp.lineman.driver".equals(s.getPackageName())) return;
  Notification n=s.getNotification(); if(n==null||n.extras==null)return;
  CharSequence a=n.extras.getCharSequence(Notification.EXTRA_TITLE), b=n.extras.getCharSequence(Notification.EXTRA_TEXT), big=n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
  String title=a==null?"":a.toString(); String text=((b==null?"":b.toString())+" "+(big==null?"":big.toString())).trim(); String all=(title+" "+text).trim();
  Intent ov=new Intent(this,JobAlertOverlayService.class); ov.putExtra("message",all); startService(ov);
  String shop=title.length()>0?title:(text.length()>60?text.substring(0,60):text);
  Matcher m=Pattern.compile("(-?\\d{1,2}\\.\\d{4,})[,\\s]+(1\\d{2}\\.\\d{4,})").matcher(all);
  Intent z=new Intent("com.apo.maekae.SHOP_CANDIDATE").setPackage(getPackageName()).putExtra("shop",shop);
  if(m.find()){try{z.putExtra("lat",Double.parseDouble(m.group(1)));z.putExtra("lon",Double.parseDouble(m.group(2)));z.putExtra("hasCoords",true);}catch(Exception ignored){}}
  sendBroadcast(z);
 }
}
