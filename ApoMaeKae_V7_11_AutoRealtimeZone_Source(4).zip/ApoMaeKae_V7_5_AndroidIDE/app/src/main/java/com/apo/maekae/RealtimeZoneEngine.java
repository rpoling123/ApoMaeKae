package com.apo.maekae;

import java.util.List;

public class RealtimeZoneEngine {
    public static class P {
        public final double lat, lon;
        public P(double lat,double lon){this.lat=lat;this.lon=lon;}
    }

    public static boolean contains(double lat,double lon,List<P> poly){
        boolean inside=false;
        for(int i=0,j=poly.size()-1;i<poly.size();j=i++){
            P a=poly.get(i), b=poly.get(j);
            boolean cross=((a.lat>lat)!=(b.lat>lat)) &&
                (lon < (b.lon-a.lon)*(lat-a.lat)/(b.lat-a.lat+1e-15)+a.lon);
            if(cross) inside=!inside;
        }
        return inside;
    }

    public static double meters(double lat1,double lon1,double lat2,double lon2){
        double R=6371000.0;
        double p1=Math.toRadians(lat1), p2=Math.toRadians(lat2);
        double dp=Math.toRadians(lat2-lat1), dl=Math.toRadians(lon2-lon1);
        double a=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
        return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
    }

    public static double nearestVertexMeters(double lat,double lon,List<P> poly){
        double best=Double.MAX_VALUE;
        for(P p:poly) best=Math.min(best,meters(lat,lon,p.lat,p.lon));
        return best;
    }
}
