ApoMaeKae V7.3 AndroidIDE
Gradle wrapper distribution: 6.7.1-all
Open the project in AndroidIDE with internet enabled for the first Gradle download.
