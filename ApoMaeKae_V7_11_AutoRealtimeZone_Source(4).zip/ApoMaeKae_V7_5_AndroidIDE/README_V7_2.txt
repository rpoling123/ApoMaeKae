ApoMaeKae V7.2 - AndroidIDE Legacy Gradle Compatibility

แก้จาก V7.1:
- ตัด dependencyResolutionManagement() ออกจาก settings.gradle
- ตัด plugins DSL รุ่นใหม่ออก
- ใช้ buildscript/classpath แบบ Gradle รุ่นเก่า
- ใช้ Android Gradle Plugin 4.2.2
- เพิ่ม package ใน AndroidManifest สำหรับ AGP รุ่นเก่า
- คง assets/โซนเดิมจาก V7.1: Polygon, ชุดมังกร, buffer 500m, GPS Zone Guard, notification/background, offline assets

AndroidIDE:
1. แตก ZIP
2. เปิดโฟลเดอร์ ApoMaeKae_V7_2_AndroidIDE
3. รอ Gradle sync
4. กด Build APK

หมายเหตุ: ชุดนี้ทำมาเพื่อแก้ error ที่ settings.gradle บรรทัด dependencyResolutionManagement() โดยเฉพาะ
