V7.9 AUTO COMPANION
- ปุ่มเริ่มงาน: เริ่ม ZoneService เดิม + เปิด LINE MAN Rider
- GPS/Polygon ใช้ระบบ Zone Guard เดิม (GPS จริง ไม่ปลอมตำแหน่ง)
- ตัวตั้งรัศมีเตือน 0.5 / 1.0 / 1.5 / 2.0 กม.
- Notification/Floating Alert จากรุ่น V7.8 (ถ้าฐาน source มีอยู่)
- ไม่ควบคุมการจ่ายงานหรือบังคับ LINE MAN Rider ให้รับเฉพาะงานตามรัศมี
Build: ./gradlew clean assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
