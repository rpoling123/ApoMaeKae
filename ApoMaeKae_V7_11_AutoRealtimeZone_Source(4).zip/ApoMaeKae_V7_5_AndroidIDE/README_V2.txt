อาโปแมะเก๊ V2

เพิ่มจาก V1:
- ใช้ภาพที่ผู้ใช้ส่งมาเป็นไอคอนแอป
- ใช้ภาพเดียวกันเป็น Splash Screen ประมาณ 2.2 วินาที
- ชื่อแอป: อาโปแมะเก๊
- เปิด https://dragonmaps-lp7unspw.manus.space/
- JavaScript / DOM Storage / Web Geolocation
- ขอสิทธิ์ GPS
- เตรียมสิทธิ์ Notification สำหรับ Android 13+
- ปุ่ม Back ย้อนหน้า WebView

สำคัญ:
V2 นี้ยังไม่ได้มี polygon/พิกัดขอบเขตโซนจริง จึงยังไม่เปิดระบบแจ้งเตือน
'ออกนอกโซน 500 เมตร' แบบ native เพื่อป้องกันการแจ้งเตือนผิดพลาด
หากเพิ่มไฟล์ KML/GeoJSON ขอบเขตโซน จะสามารถต่อระบบตรวจโซนได้

Build APK:
เปิดโฟลเดอร์ใน Android Studio > รอ Gradle Sync >
Build > Build App Bundle(s) / APK(s) > Build APK(s)
