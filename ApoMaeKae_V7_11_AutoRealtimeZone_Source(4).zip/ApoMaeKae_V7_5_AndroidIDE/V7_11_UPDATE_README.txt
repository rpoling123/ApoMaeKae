ApoMaeKae V7.11 AUTO REALTIME ZONE

เพิ่มจาก V7.10.1:
- แถบ Overlay สถานะโซนอัปเดตอัตโนมัติทุกครั้งที่ GPS อัปเดต (ประมาณ 3 วินาที)
- 4 สถานะ: อยู่ในโซน / ใกล้ขอบ / หลุดขอบแต่ยังใน Buffer 500 ม. / ออกนอก Zone Lock
- แจ้งเตือนและสั่นเมื่อสถานะเปลี่ยน
- อ่านชื่อร้านจาก LINE MAN notification เมื่อ Android เปิด Notification Access
- ถ้า notification มีพิกัดร้าน: ตรวจใน/นอก Polygon, คำนวณระยะจาก GPS ปัจจุบัน และเตือนถ้าเกินระยะ 0.5-2.0 กม. ที่ตั้งไว้
- Companion ไม่แก้ GPS ของ LINE MAN และไม่บังคับระบบ LINE MAN ให้ส่ง/ไม่ส่งงาน

Build AndroidIDE:
./gradlew clean assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
