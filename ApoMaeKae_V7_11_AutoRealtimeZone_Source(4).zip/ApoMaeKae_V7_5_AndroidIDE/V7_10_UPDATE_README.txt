V7.10 Realtime Zone Auto Companion
ฐานโปรเจกต์: V7.9 ที่ผู้ใช้อัปโหลด

คงของ V7.9:
- เริ่ม Companion + เปิด LINE MAN Rider
- Zone Guard / Background GPS เดิม
- ตัวตั้งระยะสูงสุด 2 กม.

เพิ่ม:
- RealtimeZoneEngine สำหรับตรวจ point-in-polygon แบบเรียลไทม์
- สถานะเข้าโซน / ออกโซน และ Buffer 500m สำหรับระบบแจ้งเตือน
- โครงตรวจร้านใน/นอกโซน เมื่อ Companion มีชื่อร้านและพิกัดร้านจากข้อมูลที่ Android อนุญาต
- config ระยะ 0.5/1.0/1.5/2.0 กม.
- ใช้ GPS จริงเท่านั้น ไม่แก้ GPS ของ LINE MAN Rider
- ไม่ควบคุม/กรองการจ่ายงานฝั่งเซิร์ฟเวอร์ LINE MAN

Build AndroidIDE:
./gradlew clean assembleDebug
APK:
app/build/outputs/apk/debug/app-debug.apk
