ApoMaeKae V7.4 AndroidIDE
- Gradle wrapper: 6.7.1
- Gradle daemon disabled
- Parallel build disabled
- Worker count limited to 1
- JVM heap limited for Android devices

IMPORTANT: 'server starting...wait...' is AndroidIDE's build-server startup stage.
If AndroidIDE itself cannot start its server, project Gradle files are not yet being executed.
