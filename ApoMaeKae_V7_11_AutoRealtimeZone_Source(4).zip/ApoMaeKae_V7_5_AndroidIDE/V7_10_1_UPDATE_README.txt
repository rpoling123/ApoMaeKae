V7.10.1 REALTIME ZONE COMPANION
- GPS realtime foreground ZoneService
- แจ้งเตือน เข้าโซน / ใกล้ขอบ / หลุดขอบ / ออกเกิน Buffer 500 ม.
- Overlay เตือนขณะเปิด LINE MAN Rider (เมื่ออนุญาต Display over other apps)
- หน้าหลักแสดงสถานะโซนแบบ realtime
- Notification Access อ่านเฉพาะข้อความแจ้งเตือนที่ Android เปิดเผยให้ Companion
- แสดงชื่อร้านล่าสุดจาก notification
- ถ้า notification มี latitude/longitude จะตรวจร้านใน/นอก Polygon ให้ทันที
- ถ้าไม่มีพิกัด จะขึ้นว่า “พบชื่อร้าน แต่ยังระบุใน/นอกโซนไม่ได้” (ไม่เดาพิกัด)
- รัศมีเตือนตั้งได้ 0.5 / 1.0 / 1.5 / 2.0 กม.
- ไม่แก้ GPS และไม่ควบคุมระบบจัดงานของ LINE MAN

AndroidIDE build:
./gradlew clean assembleDebug
APK:
app/build/outputs/apk/debug/app-debug.apk
