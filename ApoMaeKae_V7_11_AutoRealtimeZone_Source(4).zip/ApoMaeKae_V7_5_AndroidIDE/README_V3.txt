อาโปแมะเก๊ V3 — ฝัง KMZ/KML 4 ชุด

- อินใช้ประจำ + อินรับหน้าฝน ยอดฮิต Lineman.kmz | KML 1 | Placemark 11 | Polygon 11 | Line 0 | Point 0
- รวมอินสาย+อินเพิ่มพิเศษ โครงการจบไปแล้ว.kmz | KML 1 | Placemark 8 | Polygon 9 | Line 0 | Point 0
- รวมทุกมังกรเลือกติ๊กได้ครับ  Lineman.kmz | KML 1 | Placemark 9 | Polygon 9 | Line 0 | Point 0
- map โซนรามอินทรา ตลิ่งชัน.kmz | KML 1 | Placemark 8 | Polygon 10 | Line 0 | Point 0

ข้อมูลโซนต้นฉบับถูกฝังใน app/src/main/assets/zones
ถ้าเว็บ Dragon Maps โหลดไม่ได้ แอปจะแสดงหน้า Offline ภายในเครื่องแทน

หมายเหตุ: V3 นี้เก็บข้อมูลโซนแบบออฟไลน์แล้ว แต่แผนที่ฐาน Google/Dragon Maps
ยังต้องใช้อินเทอร์เน็ตหากไม่ได้มี tile map offline แยกต่างหาก
