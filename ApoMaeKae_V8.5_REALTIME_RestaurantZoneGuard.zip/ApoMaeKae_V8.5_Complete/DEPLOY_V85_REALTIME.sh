#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/server"
node --check server.js
npm install --omit=dev
printf '\nV8.5 realtime server ready.\n'
printf 'Required Render env: ADMIN_TOKEN, GOOGLE_MAPS_API_KEY\n'
