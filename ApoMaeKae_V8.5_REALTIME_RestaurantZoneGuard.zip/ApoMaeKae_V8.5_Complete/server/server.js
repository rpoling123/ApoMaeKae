const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 8080);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY || process.env.GOOGLE_PLACES_API_KEY || '';
const ZONES_FILE = path.join(__dirname, 'zones.json');
const DB = path.join(__dirname, 'licenses.json');
const PUBLIC = path.join(__dirname, 'public');

if (!ADMIN_TOKEN) {
  console.error('ERROR: ADMIN_TOKEN is required. Example: ADMIN_TOKEN="change-me" npm start');
  process.exit(1);
}

function readDb(){ try{return JSON.parse(fs.readFileSync(DB,'utf8'));}catch{return {keys:{}};} }
function writeDb(x){ const tmp=DB+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(x,null,2)); fs.renameSync(tmp,DB); }
function keyNorm(v){return String(v||'').trim().toUpperCase();}
function makeKey(){return 'APO-'+crypto.randomBytes(4).toString('hex').toUpperCase()+'-'+crypto.randomBytes(4).toString('hex').toUpperCase();}
function dateMs(v){const t=new Date(v).getTime();return Number.isFinite(t)?t:0;}
function send(res,status,obj){const body=JSON.stringify(obj);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(body);}
function authorized(req){const a=Buffer.from(req.headers['x-admin-token']||'');const b=Buffer.from(ADMIN_TOKEN);return a.length===b.length&&crypto.timingSafeEqual(a,b);}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>32768)req.destroy();});req.on('end',()=>{try{resolve(s?JSON.parse(s):{});}catch(e){reject(e);}});req.on('error',reject);});}
function serveFile(res,file){try{const ext=path.extname(file);const type=ext==='.html'?'text/html; charset=utf-8':'application/octet-stream';res.writeHead(200,{'Content-Type':type});res.end(fs.readFileSync(file));}catch{send(res,404,{error:'not found'});}}

function readZones(){try{return JSON.parse(fs.readFileSync(ZONES_FILE,'utf8'));}catch{return {groups:[]};}}
function pointInPolygon(lat,lon,points){
  let inside=false;
  for(let i=0,j=points.length-1;i<points.length;j=i++){
    const yi=points[i][0],xi=points[i][1],yj=points[j][0],xj=points[j][1];
    if(((yi>lat)!=(yj>lat))&&(lon<(xj-xi)*(lat-yi)/(yj-yi+1e-15)+xi)) inside=!inside;
  }
  return inside;
}
function haversine(a,b,c,d){const R=6371000,p1=a*Math.PI/180,p2=c*Math.PI/180,dp=(c-a)*Math.PI/180,dl=(d-b)*Math.PI/180;const x=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.asin(Math.min(1,Math.sqrt(x)));}
function segmentDistanceMeters(lat,lon,alat,alon,blat,blon){
  const ref=111320, x1=(alon-lon)*Math.cos(lat*Math.PI/180)*ref, y1=(alat-lat)*ref, x2=(blon-lon)*Math.cos(lat*Math.PI/180)*ref, y2=(blat-lat)*ref;
  const dx=x2-x1,dy=y2-y1,t=Math.max(0,Math.min(1,(-(x1*dx+y1*dy)/(dx*dx+dy*dy||1))));
  return Math.hypot(x1+t*dx,y1+t*dy);
}
function zoneInfo(lat,lon){
  const z=readZones(), found=[];
  for(const g of (z.groups||[])) for(const p of (g.polygons||[])){
    const pts=p.points||[]; if(pts.length<3) continue;
    if(pointInPolygon(lat,lon,pts)) found.push({groupId:g.id,name:p.name||g.name,groupName:g.name||'',bufferMeters:Number(z.bufferMeters||500)});
  }
  let nearest=null;
  for(const g of (z.groups||[])) for(const p of (g.polygons||[])){
    const pts=p.points||[]; if(pts.length<2) continue;
    let d=Infinity; for(let i=0;i<pts.length;i++){const a=pts[i],b=pts[(i+1)%pts.length];d=Math.min(d,segmentDistanceMeters(lat,lon,a[0],a[1],b[0],b[1]));}
    if(d<(nearest?.distanceMeters??Infinity)) nearest={distanceMeters:Math.round(d),name:p.name||g.name||''};
  }
  return {inside:found.length>0,zones:found,nearestBoundary:nearest};
}
async function nearbyRestaurants(lat,lon,radius,maxResults){
  if(!GOOGLE_MAPS_API_KEY) throw new Error('GOOGLE_MAPS_API_KEY is not configured');
  const r=await fetch('https://places.googleapis.com/v1/places:searchNearby',{
    method:'POST',headers:{'Content-Type':'application/json','X-Goog-Api-Key':GOOGLE_MAPS_API_KEY,'X-Goog-FieldMask':'places.id,places.displayName,places.formattedAddress,places.location,places.googleMapsUri,places.primaryType,places.businessStatus'},
    body:JSON.stringify({includedTypes:['restaurant'],maxResultCount:maxResults,rankPreference:'DISTANCE',languageCode:'th',regionCode:'TH',locationRestriction:{circle:{center:{latitude:lat,longitude:lon},radius}}})
  });
  const data=await r.json().catch(()=>({}));
  if(!r.ok){const e=new Error(data?.error?.message||`Google Places HTTP ${r.status}`);e.status=r.status;e.google=data;throw e;}
  return data;
}

const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,'http://localhost');

    if(req.method==='GET'&&u.pathname==='/api/restaurants/nearby'){
      if(!GOOGLE_MAPS_API_KEY)return send(res,503,{error:'GOOGLE_MAPS_API_KEY is not configured'});
      const lat=Number(u.searchParams.get('lat')),lon=Number(u.searchParams.get('lng'));
      const radiusRaw=Number(u.searchParams.get('radius')||1000),maxRaw=Number(u.searchParams.get('max')||20);
      const radius=Number.isFinite(radiusRaw)?Math.min(50000,Math.max(1,radiusRaw)):1000;
      const maxResults=Number.isFinite(maxRaw)?Math.min(20,Math.max(1,Math.floor(maxRaw))):20;
      const sameZone=u.searchParams.get('sameZone')==='1';
      if(!Number.isFinite(lat)||lat<-90||lat>90||!Number.isFinite(lon)||lon<-180||lon>180)return send(res,400,{error:'lat/lng ไม่ถูกต้อง'});
      try{
        const userZone=zoneInfo(lat,lon),data=await nearbyRestaurants(lat,lon,radius,maxResults);
        let places=(data.places||[]).map(p=>{
          const plat=p.location?.latitude,plon=p.location?.longitude; const zi=(Number.isFinite(plat)&&Number.isFinite(plon))?zoneInfo(plat,plon):{inside:false,zones:[],nearestBoundary:null};
          const same=zi.zones.some(z=>userZone.zones.some(u=>u.name===z.name));
          return {...p,zoneInfo:zi,inSameZone:same};
        });
        if(sameZone && userZone.zones.length) places=places.filter(p=>p.inSameZone);
        return send(res,200,{ok:true,source:'Google Maps Platform Places API (New)',center:{lat,lon},radius,maxResults,sameZone,userZone,places});
      }catch(e){console.error('nearby restaurants error:',e.message);return send(res,e.status&&e.status>=400&&e.status<600?e.status:502,{error:e.message,google:e.google?.error?.status||undefined});}
    }

    // Realtime rider heartbeat/location. Keeps only latest position per device.
    if(req.method==='POST'&&u.pathname==='/api/rider/location'){
      const b=await body(req), deviceId=String(b.deviceId||'').trim();
      const lat=validCoord(b.lat,-90,90), lng=validCoord(b.lng,-180,180);
      if(!deviceId||lat===null||lng===null)return send(res,400,{ok:false,error:'deviceId/lat/lng ไม่ถูกต้อง'});
      const file=path.join(__dirname,'riders_live.json'); let db={};
      try{db=JSON.parse(fs.readFileSync(file,'utf8'));}catch{}
      db[deviceId]={deviceId,lat,lng,accuracy:Number(b.accuracy||0),updatedAt:new Date().toISOString(),licenseKey:keyNorm(b.licenseKey)};
      fs.writeFileSync(file,JSON.stringify(db,null,2));
      return send(res,200,{ok:true,updatedAt:db[deviceId].updatedAt});
    }

    if(u.pathname==='/api/license/check'&&req.method==='POST'){
      const b=await body(req),key=keyNorm(b.key),deviceId=String(b.deviceId||'').trim(),now=Date.now(),db=readDb(),lic=db.keys[key];
      if(!key||!deviceId)return send(res,400,{active:false,message:'ต้องมี key และ deviceId',serverTime:now});
      if(!lic)return send(res,404,{active:false,message:'ไม่พบ Key',serverTime:now});
      lic.devices=Array.isArray(lic.devices)?lic.devices:[];
      const start=dateMs(lic.startAt),end=dateMs(lic.expiresAt);
      if(lic.revoked)return send(res,200,{active:false,message:'Key ถูกระงับ',serverTime:now,expiresAt:end});
      if(!start||!end||end<=start)return send(res,200,{active:false,message:'ข้อมูลวันของ Key ไม่ถูกต้อง',serverTime:now});
      if(now<start)return send(res,200,{active:false,message:'ยังไม่ถึงวันเริ่มใช้งาน',serverTime:now,startsAt:start,expiresAt:end});
      if(now>=end)return send(res,200,{active:false,message:'Key หมดอายุแล้ว',serverTime:now,expiresAt:end});
      if(!lic.devices.includes(deviceId)){
        if(lic.devices.length>=Number(lic.maxDevices||1))return send(res,200,{active:false,message:'Key ถูกใช้ครบจำนวนเครื่องแล้ว',serverTime:now,expiresAt:end,maxDevices:lic.maxDevices,usedDevices:lic.devices.length});
        lic.devices.push(deviceId);
      }
      lic.lastSeenAt=new Date(now).toISOString();writeDb(db);
      return send(res,200,{active:true,message:'OK',serverTime:now,startsAt:start,expiresAt:end,maxDevices:Number(lic.maxDevices||1),usedDevices:lic.devices.length});
    }

    if(u.pathname.startsWith('/api/admin/')){
      if(!authorized(req))return send(res,401,{error:'unauthorized'});
      const b=await body(req);
      if(req.method==='GET'&&u.pathname==='/api/admin/keys')return send(res,200,readDb().keys);
      if(req.method==='POST'&&u.pathname==='/api/admin/keys'){
        const start=dateMs(b.startDate),end=dateMs(b.expiresDate),maxDevices=Math.max(1,Math.min(10000,Number(b.maxDevices||1)));
        if(!start||!end||end<=start)return send(res,400,{error:'startDate/expiresDate ไม่ถูกต้อง'});
        const db=readDb();let key=makeKey();while(db.keys[key])key=makeKey();
        db.keys[key]={key,startAt:new Date(start).toISOString(),expiresAt:new Date(end).toISOString(),maxDevices,devices:[],revoked:false,createdAt:new Date().toISOString()};writeDb(db);return send(res,200,db.keys[key]);
      }
      if(req.method==='POST'&&['/api/admin/revoke','/api/admin/unrevoke','/api/admin/reset-devices'].includes(u.pathname)){
        const key=keyNorm(b.key),db=readDb(),lic=db.keys[key];if(!lic)return send(res,404,{error:'ไม่พบ Key'});
        if(u.pathname.endsWith('/revoke')){lic.revoked=true;lic.revokedAt=new Date().toISOString();}
        if(u.pathname.endsWith('/unrevoke')){lic.revoked=false;delete lic.revokedAt;}
        if(u.pathname.endsWith('/reset-devices')){lic.devices=[];lic.resetAt=new Date().toISOString();}
        writeDb(db);return send(res,200,lic);
      }
    }
    return send(res,404,{error:'not found'});
  }catch(e){console.error(e);return send(res,500,{error:'server error'});}
});
server.listen(PORT,()=>console.log(`ApoMaeKae License Server listening on :${PORT}`));
