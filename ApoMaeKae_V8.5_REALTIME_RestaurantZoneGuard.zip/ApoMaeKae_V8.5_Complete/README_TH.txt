ApoMaeKae V8.5 REALTIME
======================

ฟังก์ชัน Android:
- Zone Guard 500m ทำงานเบื้องหลัง
- เลือกกลุ่มโซนแบบติ๊ก
- License เชื่อม https://apomaekae-2.onrender.com
- ร้านอาหารใกล้ฉันจาก Google Places
- ส่งตำแหน่ง Rider ไป Server ทุก 15 วินาทีเมื่อเริ่ม Zone Guard

ฟังก์ชัน Server:
- /api/license/check
- /api/restaurants/nearby
- /api/rider/location (เก็บตำแหน่งล่าสุดของแต่ละ device)
- /api/health
- Google Places API อยู่ฝั่ง Server ไม่ฝัง API Key ใน APK

ตัดออกแล้ว:
- ร้านแนะนำ / recommendation / ranking

Render Environment:
ADMIN_TOKEN=...
GOOGLE_MAPS_API_KEY=...

APK:
โปรเจกต์ Android มี GitHub Actions สำหรับ Build APK ที่
.github/workflows/android-apk.yml
สามารถกด Actions > Build ApoMaeKae APK > Run workflow
